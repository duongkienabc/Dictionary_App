package Screen;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;

public class AppScreenController {

    @FXML
    private Button buttonAW;

    @FXML
    private Button buttonOut;

    @FXML
    private Button buttonSAW;

    @FXML
    private Button buttonSW;

    @FXML
    private Button buttonTrans;

    @FXML
    private Button gamebutton;

    @FXML
    private ImageView imageView;



}
