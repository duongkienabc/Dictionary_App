package Screen;

import DictionaryCommandLine.Word;
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.web.WebView;
import javafx.stage.Stage;

import java.io.*;
import java.util.*;

public class AddWords extends Application {
    @FXML
    private Button buttonAdd;

    @FXML
    private Button buttonDelete;

    @FXML
    private ListView<String> listView;

    @FXML
    private TextField textMeaning;

    @FXML
    private TextField textWord;

    @FXML
    private WebView webView;
    private Map<String, Word> data = new HashMap<>();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader();
        AnchorPane root = fxmlLoader.load(getClass().getResourceAsStream("AddWords.fxml"));
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();
        primaryStage.setTitle("AddWords");
    }

    @FXML
    public void addWord() {
        String word = textWord.getText().trim();
        String meaning = textMeaning.getText().trim();
        if (!word.isEmpty() && !meaning.isEmpty()) {
            try {
                BufferedWriter writer = new BufferedWriter(new FileWriter("src/data/Learn.txt", true));
                writer.write(word + "<html>" + meaning + "\n");
                writer.close();
                Word newWord = new Word(word, "<html>" + meaning);
                data.put(word, newWord);
                listView.getItems().add(word);
                textWord.clear();
                textMeaning.clear();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void initComponents(AnchorPane root) {
        this.webView = (WebView) root.lookup("#webView");
        this.listView = (ListView<String>) root.lookup("#listView");
        this.textWord = (TextField) root.lookup("#searchField");
        this.textMeaning = (TextField) root.lookup("#searchField");

    }

}